#include <iostream>

int main()
{
    std::cout << "Kake!" << std::endl;
    return 0;
}
            