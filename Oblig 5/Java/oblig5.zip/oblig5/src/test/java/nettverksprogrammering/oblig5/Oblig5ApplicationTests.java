package nettverksprogrammering.oblig5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oblig5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
